import React, { useState } from 'react';
import { 
  DefenseMessage, 
  InternshipTask 
} from '../types';
import { 
  INITIAL_DEFENSE_MESSAGES, 
  SAMPLE_DEFENSE_ANSWER, 
  SAMPLE_DEFENSE_FOLLOWUP, 
  SAMPLE_FOLLOWUP_ANSWER 
} from '../mockData';
import { 
  Bot, 
  User, 
  Send, 
  CheckCircle2, 
  ArrowRight, 
  ShieldCheck
} from 'lucide-react';

interface Stage8ExplanationProps {
  task: InternshipTask;
  onDefenseComplete: () => void;
  lang: 'en' | 'ru';
}

export const Stage8Explanation: React.FC<Stage8ExplanationProps> = ({
  task,
  onDefenseComplete,
  lang
}) => {
  const [messages, setMessages] = useState<DefenseMessage[]>(INITIAL_DEFENSE_MESSAGES);
  const [defenseStage, setDefenseStage] = useState<'initial-q' | 'student-a1' | 'followup-q' | 'student-a2' | 'verified'>('initial-q');
  const [inputText, setInputText] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Student submits Answer 1
  const handleStudentAnswer1 = (textToUse?: string) => {
    const ansText = textToUse || inputText || SAMPLE_DEFENSE_ANSWER;
    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });

    const newMsg: DefenseMessage = {
      id: `ans-1-${Date.now()}`,
      sender: 'student',
      text: ansText,
      timestamp: timeStr
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
    setDefenseStage('followup-q');
    setIsAiThinking(true);

    // AI analyzes and poses Follow-up Question
    setTimeout(() => {
      setIsAiThinking(false);
      const followupMsg: DefenseMessage = {
        id: `q-followup-${Date.now()}`,
        sender: 'ai',
        text: SAMPLE_DEFENSE_FOLLOWUP,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false })
      };
      setMessages((prev) => [...prev, followupMsg]);
      setDefenseStage('student-a2');
    }, 1000);
  };

  // Student submits Answer 2
  const handleStudentAnswer2 = (textToUse?: string) => {
    const ansText = textToUse || inputText || SAMPLE_FOLLOWUP_ANSWER;
    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });

    const newMsg: DefenseMessage = {
      id: `ans-2-${Date.now()}`,
      sender: 'student',
      text: ansText,
      timestamp: timeStr
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
    setIsAiThinking(true);

    // AI verifies defense
    setTimeout(() => {
      setIsAiThinking(false);
      setDefenseStage('verified');
      const passMsg: DefenseMessage = {
        id: `pass-${Date.now()}`,
        sender: 'ai',
        text: lang === 'ru'
          ? 'Защита пройдена. Концептуальная целостность и понимание распределенного консенсуса подтверждены на 94/100. Генерирую доказательства.'
          : 'Defense verified. Core algorithmic grounding and invariant retention confirmed at 94/100. Generating cryptographic evidence bundle.',
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false })
      };
      setMessages((prev) => [...prev, passMsg]);
    }, 1000);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 text-left space-y-6 select-none">
      {/* Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
              {lang === 'ru' ? 'Шаг 8' : 'Step 8'}
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs font-mono text-slate-400">
              AI Defense Dialogue
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {lang === 'ru' ? 'Защита решения' : 'Defense Session'}
          </h2>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-mono">
          <Bot className="w-3.5 h-3.5 text-purple-400" />
          <span>Examiner Active</span>
        </div>
      </div>

      {/* Chat Dialogue Stream Card */}
      <div className="rounded-3xl bg-[#0e1118] border border-white/[0.08] p-5 sm:p-6 space-y-4">
        <div className="space-y-3.5 max-h-[460px] overflow-y-auto pr-1">
          {messages.map((msg) => {
            const isAi = msg.sender === 'ai';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 text-left ${isAi ? 'justify-start' : 'justify-end'}`}
              >
                {isAi && (
                  <div className="w-7 h-7 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300 shrink-0 mt-0.5">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                    isAi
                      ? 'bg-white/[0.03] border border-white/[0.08] text-slate-200'
                      : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  }`}
                >
                  <p>{msg.text}</p>
                  <span className={`block text-[10px] font-mono mt-1 ${isAi ? 'text-slate-500' : 'text-blue-200'}`}>
                    {msg.timestamp}
                  </span>
                </div>

                {!isAi && (
                  <div className="w-7 h-7 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isAiThinking && (
            <div className="flex gap-3 text-left">
              <div className="w-7 h-7 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300 shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.08] text-xs font-mono text-slate-400 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                <span>AI evaluating reasoning...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar & Preset Answer Shortcuts */}
        <div className="pt-3 border-t border-white/[0.06] space-y-3">
          {/* Quick presets */}
          {defenseStage === 'initial-q' && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <span className="text-[11px] font-mono text-slate-500 shrink-0">
                {lang === 'ru' ? 'Быстрый ответ:' : 'Quick answer:'}
              </span>
              <button
                onClick={() => handleStudentAnswer1(SAMPLE_DEFENSE_ANSWER)}
                className="px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.1] text-xs text-cyan-300 truncate max-w-md transition-colors cursor-pointer"
              >
                "{SAMPLE_DEFENSE_ANSWER.slice(0, 56)}..."
              </button>
            </div>
          )}

          {defenseStage === 'student-a2' && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <span className="text-[11px] font-mono text-slate-500 shrink-0">
                {lang === 'ru' ? 'Быстрый ответ:' : 'Quick answer:'}
              </span>
              <button
                onClick={() => handleStudentAnswer2(SAMPLE_FOLLOWUP_ANSWER)}
                className="px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.1] text-xs text-purple-300 truncate max-w-md transition-colors cursor-pointer"
              >
                "{SAMPLE_FOLLOWUP_ANSWER.slice(0, 56)}..."
              </button>
            </div>
          )}

          {/* Text input form */}
          {defenseStage !== 'verified' ? (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  defenseStage === 'student-a2'
                    ? (lang === 'ru' ? 'Ответ на follow-up вопрос...' : 'Answer the follow-up question...')
                    : (lang === 'ru' ? 'Введите ответ для AI...' : 'Explain your architectural choice...')
                }
                className="flex-1 px-4 py-2.5 rounded-xl bg-black/40 border border-white/[0.08] text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/60"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    if (defenseStage === 'student-a2') handleStudentAnswer2();
                    else handleStudentAnswer1();
                  }
                }}
              />
              <button
                onClick={() => {
                  if (defenseStage === 'student-a2') handleStudentAnswer2();
                  else handleStudentAnswer1();
                }}
                className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
              <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>{lang === 'ru' ? 'Защита успешно зачтена (94/100)' : 'Defense Verified (94/100)'}</span>
              </div>
              <button
                onClick={onDefenseComplete}
                className="px-4 py-2 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:opacity-95 transition-opacity flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <span>{lang === 'ru' ? 'К уликам (Шаг 9)' : 'Generate Evidence (Step 9)'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
