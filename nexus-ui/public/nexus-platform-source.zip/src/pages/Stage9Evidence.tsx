import React, { useState } from 'react';
import { WorkEvent, InternshipTask } from '../types';
import { 
  ShieldCheck, 
  Hash, 
  Cpu, 
  CheckCircle2, 
  ArrowRight, 
  Lock, 
  Award,
  Layers
} from 'lucide-react';

interface Stage9EvidenceProps {
  task: InternshipTask;
  workEvents: WorkEvent[];
  onMintPassport: () => void;
  lang: 'en' | 'ru';
}

export const Stage9Evidence: React.FC<Stage9EvidenceProps> = ({
  task,
  workEvents,
  onMintPassport,
  lang
}) => {
  const [isMinting, setIsMinting] = useState(false);
  const merkleRoot = '0x8f2a91b48d21c97034b7f83e84210d7a04918e7e1c84d62b9a7c8194f0e213b9';

  const handleMint = () => {
    setIsMinting(true);
    setTimeout(() => {
      setIsMinting(false);
      onMintPassport();
    }, 900);
  };

  const humanEvents = workEvents.filter((e) => e.actor === 'HUMAN').length;
  const aiEvents = workEvents.filter((e) => e.actor === 'AI').length;
  const humanRatio = Math.round((humanEvents / Math.max(1, humanEvents + aiEvents)) * 100);
  const aiRatio = 100 - humanRatio;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 text-left space-y-6 select-none">
      {/* Editorial Header */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <span className="text-xs font-mono text-cyan-400 font-bold tracking-wider uppercase">
          {lang === 'ru' ? 'Шаг 9 · Доказательства' : 'Step 9 · Evidence Generated'}
        </span>
        <h2 className="text-3xl font-black text-white tracking-tight">
          {lang === 'ru' ? 'Пакет доказательств' : 'Evidence Manifest'}
        </h2>
        <p className="text-slate-400 text-xs sm:text-sm">
          {lang === 'ru'
            ? 'Все WorkEvents, канва и ответы защиты запечатаны в Merkle-дерево.'
            : 'WorkEvents, canvas topology, and defense records sealed into Merkle tree.'}
        </p>
      </div>

      {/* Main Evidence Card */}
      <div className="rounded-3xl bg-[#0e1118] border border-white/[0.08] p-6 sm:p-8 space-y-6">
        {/* Merkle Root Banner */}
        <div className="p-4 rounded-2xl bg-black/60 border border-white/[0.08] space-y-1.5">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-cyan-400" />
              Merkle Root Hash
            </span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified
            </span>
          </div>
          <div className="text-xs font-mono text-cyan-300 break-all bg-white/[0.02] p-2 rounded-xl border border-white/[0.04]">
            {merkleRoot}
          </div>
        </div>

        {/* 3 Telemetry Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Human/AI Telemetry</div>
            <div className="text-base font-bold text-white flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>{humanRatio}% / {aiRatio}%</span>
            </div>
            <div className="text-[10px] text-slate-400">Zero fraud detected</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Oral Defense</div>
            <div className="text-base font-bold text-white flex items-center gap-1.5">
              <Award className="w-4 h-4 text-purple-400" />
              <span>94 / 100</span>
            </div>
            <div className="text-[10px] text-slate-400">Examiner approved</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Canvas Schema</div>
            <div className="text-base font-bold text-white flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>SVG Invariants</span>
            </div>
            <div className="text-[10px] text-slate-400">Cryptographically bound</div>
          </div>
        </div>

        {/* Mint Button to Step 10 */}
        <div className="pt-2">
          <button
            onClick={handleMint}
            disabled={isMinting}
            className="w-full py-3.5 px-6 rounded-2xl font-bold text-sm text-slate-950 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 hover:opacity-95 transition-opacity flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
          >
            {isMinting ? (
              <>
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>{lang === 'ru' ? 'Выпуск паспорта...' : 'Issuing Passport...'}</span>
              </>
            ) : (
              <>
                <span>
                  {lang === 'ru'
                    ? 'Выпустить Nexus Passport (Шаг 10)'
                    : 'Issue Nexus Passport (Step 10)'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
